import{d as g,r as m,k as w,s as h,h as v,T as k,c as x,b as f,a as t,t as y,p as l,o as i}from"./index-CipsPQfb.js";const b=["innerHTML"],M=g({__name:"Toast",props:{show:{type:Boolean},type:{default:"success"},message:{},duration:{default:3e3}},emits:["close"],setup(o,{emit:c}){const e=o,n=c,s=m(!1);w(()=>e.show,a=>{a&&(s.value=!0,setTimeout(()=>{s.value=!1,setTimeout(()=>n("close"),300)},e.duration))});const u=()=>{switch(e.type){case"success":return`
        <svg class="w-6 h-6 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      `;case"error":return`
        <svg class="w-6 h-6 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      `;case"warning":return`
        <svg class="w-6 h-6 text-yellow-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
        </svg>
      `;case"info":return`
        <svg class="w-6 h-6 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      `}},d=()=>{switch(e.type){case"success":return"bg-green-50 border-green-200";case"error":return"bg-red-50 border-red-200";case"warning":return"bg-yellow-50 border-yellow-200";case"info":return"bg-blue-50 border-blue-200"}},p=()=>{switch(e.type){case"success":return"text-green-800";case"error":return"text-red-800";case"warning":return"text-yellow-800";case"info":return"text-blue-800"}};return(a,r)=>(i(),h(k,{"enter-active-class":"transition ease-out duration-300","enter-from-class":"translate-y-2 opacity-0","enter-to-class":"translate-y-0 opacity-100","leave-active-class":"transition ease-in duration-200","leave-from-class":"translate-y-0 opacity-100","leave-to-class":"translate-y-2 opacity-0"},{default:v(()=>[s.value?(i(),x("div",{key:0,class:l(["fixed top-4 right-4 z-50 flex items-center gap-3 px-4 py-3 rounded-lg border shadow-lg min-w-[300px] max-w-md",d()])},[t("div",{innerHTML:u(),class:"flex-shrink-0"},null,8,b),t("p",{class:l(["flex-1 text-sm font-medium",p()])},y(o.message),3),t("button",{onClick:r[0]||(r[0]=C=>{s.value=!1,n("close")}),class:"flex-shrink-0 text-gray-400 hover:text-gray-600 transition"},[...r[1]||(r[1]=[t("svg",{class:"w-5 h-5",fill:"none",stroke:"currentColor",viewBox:"0 0 24 24"},[t("path",{"stroke-linecap":"round","stroke-linejoin":"round","stroke-width":"2",d:"M6 18L18 6M6 6l12 12"})],-1)])])],2)):f("",!0)]),_:1}))}});export{M as _};
